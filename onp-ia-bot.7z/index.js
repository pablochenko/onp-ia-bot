require ('dotenv').config();
const express = require('express')
const {WebhookClient} = require('dialogflow-fulfillment')
const {Card, Suggestion, Payload} = require('dialogflow-fulfillment');
//const request = require("request");
//const exphbs = require("express-handlebars");
//const http = require('https')
const crypto = require("crypto");
const axios = require("axios");
const jwt_decode = require('jwt-decode');

const app = express()
app.use(express.json())

const publicKey=`-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCDsMd37llJw4NLq57498yjhU3Z
lsZGYOUqRArapO/SI7ajdQ8n4C/7hK+kXFNR7P1wCE5FmJ1KL4YOxEEG3+RcG37K
Hx9qvk328ciVMlNQgKKNpX3sKSegyp+vRFLS/xpfgq7lTMxKl0RPc4avnAOcM6vA
YCF0lN/+QKAR7IiwOQIDAQAB
-----END PUBLIC KEY-----`;


const apiGetTokenClaveVirtual='https://uat.onp.gob.pe/SeguridadDev/api/Auth/loginApps';
const apigetTokenLogin='https://uat.onp.gob.pe/ClaveVirtualAPI/api/login/PostLogin';

function handleResponse(status,data)
{
    const response=
    {
        "status":status,
        "data":data
    }
    return response;
}

  function getEncryptRsa(clave)
  {
    const encryptedData = crypto.publicEncrypt(
        {
          key: publicKey,
          padding: crypto.constants.RSA_PKCS1_PADDING,
        },
        Buffer.from(clave)
      );
    return encryptedData.toString("base64");

  }

function validUserClaveVirtual(idTipDoc,numDoc,clave)
{
    const claveEncryptRsa=getEncryptRsa(clave);

    const headers={'Content-Type':'application/json'}; 
	const parms={IdTipoDocumento:idTipDoc,NumeroDocumento:numDoc,Clave:claveEncryptRsa,CodigoAplicacion:'MOVIL'};  

    const result = new Promise(function(resolve, reject) {
   axios.post(apiGetTokenClaveVirtual,parms,headers)
  .then(function (res) {
     const data=res.data;
     if(data.IsSuccess && data.Codigo=='0000')
   {
    resolve(handleResponse(true,data.ResultToken)); 
   }else
     {
    resolve(handleResponse(false,[]));
     }       
  })
  .catch(function (error) {
    resolve(handleResponse(false,[]));
  })  
  });
  result.catch((err) => {
    resolve(handleResponse(false,[]));
  });
  return result;

}

async function handleIntentIdentificacion(agent)
{
    /*
    const idTipDoc=agent.parameters.per_nro_doc; 
    const numDoc=agent.parameters.per_nro_doc;
    const clave=agent.parameters.per_nro_doc;
    */
    const idTipDoc="23"; 
    const numDoc="19209886";
    const clave="111111";

    const tokenJwt=await validUserClaveVirtual(idTipDoc,numDoc,clave);

    if(tokenJwt.status)
    {
      //USUARIO VALIDADO ....
      /**
        UserId: '296',
        NumDoc: '19209886',
        TypeDoc: '23',
        TypeUser: 'P',
        CodeApli: 'MOVIL',
        CodeComp: '',
        FullName: 'PASTOR ALADINO VASQUEZ SERRANO',        
        Name: 'PASTOR ALADINO',
        TypeDocDesc: 'DNI',
        FullTypeDocDesc: 'DOCUMENTO NACIONAL DE IDENTIDAD',
        DateSearch: '19/08/2022',
        DateUpdate: '18/08/2022',
        TypeDocSnp: 'DI',
        TypeDocMccia: '01',
        TypeDocNstd: 'DNI',
        TypeDocAportantes: '01',
        TypeDocCalculo: '02',
        TypeDocOnpVirtual: '1',
        Correo: 'javiervasquezpadilla@outlook.com',
        CodCelular: 'PL',
        Celular: '988889855',
        exp: 1660932254 
      */
      const datDec= jwt_decode(tokenJwt.data);
      
      agent.add(`Hola 1 ${datDec.FullName}, iniciaste sesión correctamente.`);

      const payload = {
        "telegram": {
            "text": "✔️ Ahora escoge un servicio para continuar:",
            "reply_markup": {
              "inline_keyboard": [
                [
                  {
                    "callback_data": "apo_acreditados",
                    "text": "Aportes acreditados"
                  }
                ],
                [
                  {
                    "callback_data": "boleta",
                    "text": "Boletas de pago"
                  }
                ],
                [
                   {
                     "callback_data": "cons_afiliacion",
                     "text": "Constancia de afliacion"
                   }
                 ]
              ]
            }
          }
    }
 
    agent.add(
        new Payload(agent.TELEGRAM, payload, {rawPayload: true, sendAsMessage: true})
    );
 


    }else{
     //ERROR DE VALIDACION ...

    }

}

//handleIntentIdentificacion('Identificacion');
//validUserClaveVirtual("23","19209886","111111");




function getTokenLogin()
{
    const headers={'Content-Type':'application/json'}; 
	const parms={Username:'API-CLAVE-FICHA-ASEG',Password:'645D4017-7B4C-4266-82CB-52031A49A13E'};  

    const result = new Promise(function(resolve, reject) {
   axios.post(apigetTokenLogin,parms,headers)
  .then(function (res) {
     const data=res.data;
     if(data.IsSuccess && data.Codigo=='0000')
   {
    resolve(handleResponse(true,data.Result)); 
   }else
     {
    resolve(handleResponse(false,[]));
     }        

  })
  .catch(function (error) {
    resolve(handleResponse(false,[]));
  })  

  });
  result.catch((err) => {
    resolve(handleResponse(false,[]));
  });
  return result;   
}






function welcome(agent) {    

const contexto = 'setBienvenida';        
   
const text = `¡Bienvenida/o a la ONP!🌟
Mi nombre es Olivia, la asistente virtual de la ONP. 🤖
¡Por este medio te ayudaré a resolver tus consultas! 🤝
Selecciona una de las siguientes opciones:`;

   const inline_keyboard = [[{"text": "Consultar información de mi cuenta","callback_data": "identificacion"},
                        {"text": "Solicitar o recuperar mi Clave virtual", "callback_data": "clave_virtual"}],
                        [{"text": "Consultar el cronograma de pagos","callback_data": "cronograma"},
                         {"text": "Conocer las Sedes y los horarios de atención","callback_data": "sedes_horarios"}]] ;  
    const payload = { "telegram": {"text": text,"reply_markup": {  "inline_keyboard": inline_keyboard }}};          
    agent.context.set({ name: contexto, lifespan: 2,parameters: ''});                                   
    agent.add(new Payload(agent.UNSPECIFIED , payload, {rawPayload: true, sendAsMessage: true}));

  }   



app.get('/', (req, res) => {
   res.send("servidor 1451......")

})


app.post('/webhook', (req, res) => {
    let agent = new WebhookClient({request: req, response: res})
    let intentMap = new Map();
    intentMap.set('1 Inicio Bienvenida', welcome);

    intentMap.set('Identificacion',handleIntentIdentificacion)
    agent.handleRequest(intentMap)
})

/*
function handleWebHookIntent(agent){
    agent.add("funcionando desde el webhook")
}
*/



 






app.listen(process.env.PORT)